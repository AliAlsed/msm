export const environment = {
  production: false,
  firebase: {
	apiKey: "AIzaSyBPC9W3X9RDtgbzaeFEMkU2Q-ax4HoYCPk",
    authDomain: "school-a53e4.firebaseapp.com",
    databaseURL: "https://school-a53e4.firebaseio.com",
    projectId: "school-a53e4",
    storageBucket: "school-a53e4.appspot.com",
    messagingSenderId: "729190915101"
  }
};


