 
 export interface profile {
    id: string;
    fullName: string;
    gender: string;
    stage: string;
    division: string;
    birthdate: string;
    address: string;
    mobile: string;
    email: string;
    password: string;
    tag: string;

}
