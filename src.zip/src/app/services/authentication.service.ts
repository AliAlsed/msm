import { Injectable } from "@angular/core";
import * as firebase from 'firebase/app';
import { FCM } from '@ionic-native/fcm/ngx';
import { AngularFireDatabase } from 'angularfire2/database';
 
@Injectable()
export class AuthenticateService {
 
  constructor(private db: AngularFireDatabase, private fcm: FCM ){}
 
  registerUser(value){
   return new Promise<any>((resolve, reject) => {
     firebase.auth().createUserWithEmailAndPassword(value.email, value.password)
     .then(    
       res => resolve(res),
       err => reject(err))
   }).then(()=>{
    this.addToken();
   });
  }
 
  loginUser(value){
   return new Promise<any>((resolve, reject) => {
     firebase.auth().signInWithEmailAndPassword(value.email, value.password)
     .then(
       res => resolve(res),
       err => reject(err))

   }).then(()=>{
    this.addToken();
   });

  }
 
  logoutUser(){
    return new Promise((resolve, reject) => {
      if(firebase.auth().currentUser){
        firebase.auth().signOut()
        .then(() => {
          console.log("LOG Out");
          resolve();
        }).catch((error) => {
          reject();
        });
      }
    })
  }
 
  userDetails(){
    return firebase.auth().currentUser;
  }

  addToken(){
    this.fcm.getToken().then((token) => {
      console.log(token);
      this.db.list(`token/${firebase.auth().currentUser.uid}`).set('token', token);
    });
  }
}